###### Class org.apache.commons.codec.Decoder (org.apache.commons.codec.Decoder)
.class public interface abstract Lorg/apache/commons/codec/Decoder;
.super Ljava/lang/Object;
.source "Decoder.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# virtual methods
.method public abstract decode(Ljava/lang/Object;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/apache/commons/codec/DecoderException;
        }
    .end annotation
.end method
