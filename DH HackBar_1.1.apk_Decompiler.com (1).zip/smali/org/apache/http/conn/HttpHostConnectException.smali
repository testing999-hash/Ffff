###### Class org.apache.http.conn.HttpHostConnectException (org.apache.http.conn.HttpHostConnectException)
.class public Lorg/apache/http/conn/HttpHostConnectException;
.super Ljava/net/ConnectException;
.source "HttpHostConnectException.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# direct methods
.method public constructor <init>(Lorg/apache/http/HttpHost;Ljava/net/ConnectException;)V
    .registers 5
    .param p1, "host"    # Lorg/apache/http/HttpHost;
    .param p2, "cause"    # Ljava/net/ConnectException;

    .prologue
    .line 36
    invoke-direct {p0}, Ljava/net/ConnectException;-><init>()V

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Stub!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public getHost()Lorg/apache/http/HttpHost;
    .registers 3

    .prologue
    .line 37
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Stub!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
