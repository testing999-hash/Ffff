###### Class androidx.browser.R (androidx.browser.R)
.class public final Landroidx/browser/R;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.attr (androidx.browser.R$attr)
.class public final Landroidx/browser/R$attr;
.super Ljava/lang/Object;


# static fields
.field public static adSize:I = 0x7f010000

.field public static adSizes:I = 0x7f010001

.field public static adUnitId:I = 0x7f010002

.field public static alpha:I = 0x7f01000c

.field public static coordinatorLayoutStyle:I = 0x7f010003

.field public static font:I = 0x7f010014

.field public static fontProviderAuthority:I = 0x7f01000d

.field public static fontProviderCerts:I = 0x7f010010

.field public static fontProviderFetchStrategy:I = 0x7f010011

.field public static fontProviderFetchTimeout:I = 0x7f010012

.field public static fontProviderPackage:I = 0x7f01000e

.field public static fontProviderQuery:I = 0x7f01000f

.field public static fontStyle:I = 0x7f010013

.field public static fontVariationSettings:I = 0x7f010016

.field public static fontWeight:I = 0x7f010015

.field public static keylines:I = 0x7f010004

.field public static layout_anchor:I = 0x7f010007

.field public static layout_anchorGravity:I = 0x7f010009

.field public static layout_behavior:I = 0x7f010006

.field public static layout_dodgeInsetEdges:I = 0x7f01000b

.field public static layout_insetEdge:I = 0x7f01000a

.field public static layout_keyline:I = 0x7f010008

.field public static statusBarBackground:I = 0x7f010005

.field public static ttcIndex:I = 0x7f010017


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.color (androidx.browser.R$color)
.class public final Landroidx/browser/R$color;
.super Ljava/lang/Object;


# static fields
.field public static browser_actions_bg_grey:I = 0x7f080004

.field public static browser_actions_divider_color:I = 0x7f080005

.field public static browser_actions_text_color:I = 0x7f080006

.field public static browser_actions_title_color:I = 0x7f080007

.field public static colorAccent:I = 0x7f08000a

.field public static colorControlHighlight:I = 0x7f08000b

.field public static colorControlNormal:I = 0x7f08000c

.field public static colorPrimary:I = 0x7f080008

.field public static colorPrimaryDark:I = 0x7f080009

.field public static notification_action_color_filter:I = 0x7f080000

.field public static notification_icon_bg_color:I = 0x7f080001

.field public static ripple_material_light:I = 0x7f080002

.field public static secondary_text_default_material_light:I = 0x7f080003


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.dimen (androidx.browser.R$dimen)
.class public final Landroidx/browser/R$dimen;
.super Ljava/lang/Object;


# static fields
.field public static browser_actions_context_menu_max_width:I = 0x7f070016

.field public static browser_actions_context_menu_min_padding:I = 0x7f070017

.field public static compat_button_inset_horizontal_material:I = 0x7f070004

.field public static compat_button_inset_vertical_material:I = 0x7f070005

.field public static compat_button_padding_horizontal_material:I = 0x7f070006

.field public static compat_button_padding_vertical_material:I = 0x7f070007

.field public static compat_control_corner_material:I = 0x7f070008

.field public static compat_notification_large_icon_max_height:I = 0x7f070009

.field public static compat_notification_large_icon_max_width:I = 0x7f07000a

.field public static notification_action_icon_size:I = 0x7f07000b

.field public static notification_action_text_size:I = 0x7f07000c

.field public static notification_big_circle_margin:I = 0x7f07000d

.field public static notification_content_margin_start:I = 0x7f070001

.field public static notification_large_icon_height:I = 0x7f07000e

.field public static notification_large_icon_width:I = 0x7f07000f

.field public static notification_main_column_padding_top:I = 0x7f070002

.field public static notification_media_narrow_margin:I = 0x7f070003

.field public static notification_right_icon_size:I = 0x7f070010

.field public static notification_right_side_padding_top:I = 0x7f070000

.field public static notification_small_icon_background_padding:I = 0x7f070011

.field public static notification_small_icon_size_as_large:I = 0x7f070012

.field public static notification_subtext_size:I = 0x7f070013

.field public static notification_top_pad:I = 0x7f070014

.field public static notification_top_pad_large_text:I = 0x7f070015


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.drawable (androidx.browser.R$drawable)
.class public final Landroidx/browser/R$drawable;
.super Ljava/lang/Object;


# static fields
.field public static add:I = 0x7f020000

.field public static app_icon:I = 0x7f020001

.field public static back:I = 0x7f020002

.field public static crash:I = 0x7f020003

.field public static default_image:I = 0x7f020004

.field public static findclose:I = 0x7f020005

.field public static findnext:I = 0x7f020006

.field public static findprev:I = 0x7f020007

.field public static ic_about:I = 0x7f020008

.field public static ic_changelog:I = 0x7f020009

.field public static ic_exit:I = 0x7f02000a

.field public static ic_menuclose:I = 0x7f02000b

.field public static ic_restart:I = 0x7f02000c

.field public static ic_settings:I = 0x7f02000d

.field public static ic_share:I = 0x7f02000e

.field public static ic_tutorial:I = 0x7f02000f

.field public static img:I = 0x7f020010

.field public static invisible:I = 0x7f020011

.field public static menu:I = 0x7f020012

.field public static note:I = 0x7f020013

.field public static notification_action_background:I = 0x7f020014

.field public static notification_bg:I = 0x7f020015

.field public static notification_bg_low:I = 0x7f020016

.field public static notification_bg_low_normal:I = 0x7f020017

.field public static notification_bg_low_pressed:I = 0x7f020018

.field public static notification_bg_normal:I = 0x7f020019

.field public static notification_bg_normal_pressed:I = 0x7f02001a

.field public static notification_icon_background:I = 0x7f02001b

.field public static notification_template_icon_bg:I = 0x7f020022

.field public static notification_template_icon_low_bg:I = 0x7f020023

.field public static notification_tile_bg:I = 0x7f02001c

.field public static notify_panel_notification_icon_bg:I = 0x7f02001d

.field public static redo:I = 0x7f02001e

.field public static save:I = 0x7f02001f

.field public static undo:I = 0x7f020020

.field public static visible:I = 0x7f020021


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.id (androidx.browser.R$id)
.class public final Landroidx/browser/R$id;
.super Ljava/lang/Object;


# static fields
.field public static abouticon:I = 0x7f0900c7

.field public static aboutlinear:I = 0x7f0900c6

.field public static abouttext:I = 0x7f0900c8

.field public static action_container:I = 0x7f0900d1

.field public static action_divider:I = 0x7f0900dd

.field public static action_image:I = 0x7f0900d2

.field public static action_text:I = 0x7f0900d3

.field public static actions:I = 0x7f0900de

.field public static activityname:I = 0x7f090020

.field public static activitytitle:I = 0x7f09006b

.field public static add:I = 0x7f090068

.field public static adminfinder:I = 0x7f0900a7

.field public static adminscanner:I = 0x7f0900a8

.field public static agreementstitle:I = 0x7f090048

.field public static all:I = 0x7f090017

.field public static androidversion:I = 0x7f09004f

.field public static androidversionlinear:I = 0x7f09004d

.field public static androidversiontitle:I = 0x7f09004e

.field public static appicon:I = 0x7f0900b6

.field public static applogo:I = 0x7f090024

.field public static appname:I = 0x7f090025

.field public static async:I = 0x7f090018

.field public static authbypass:I = 0x7f09009c

.field public static authorname:I = 0x7f0900b9

.field public static back:I = 0x7f09001f

.field public static backgroun:I = 0x7f0900ba

.field public static background:I = 0x7f09001d

.field public static basicstatements:I = 0x7f090086

.field public static blocking:I = 0x7f090019

.field public static body:I = 0x7f090071

.field public static bodyfield:I = 0x7f0900e3

.field public static bottom:I = 0x7f090008

.field public static browser_actions_header_text:I = 0x7f090061

.field public static browser_actions_menu_item_icon:I = 0x7f090063

.field public static browser_actions_menu_item_text:I = 0x7f090064

.field public static browser_actions_menu_items:I = 0x7f090062

.field public static browser_actions_menu_view:I = 0x7f090060

.field public static center:I = 0x7f090009

.field public static center_horizontal:I = 0x7f09000a

.field public static center_vertical:I = 0x7f09000b

.field public static chronometer:I = 0x7f0900dc

.field public static clear:I = 0x7f09007c

.field public static cleardatasetting:I = 0x7f0900f1

.field public static clip_horizontal:I = 0x7f09000c

.field public static clip_vertical:I = 0x7f09000d

.field public static close:I = 0x7f090070

.field public static columncount:I = 0x7f090084

.field public static copy:I = 0x7f090080

.field public static copyright:I = 0x7f090027

.field public static crashicon:I = 0x7f09006a

.field public static creditstitle:I = 0x7f090038

.field public static customquery:I = 0x7f090092

.field public static datentime:I = 0x7f090072

.field public static developedbytitle:I = 0x7f090028

.field public static deviceid:I = 0x7f090057

.field public static deviceidlinear:I = 0x7f090055

.field public static deviceidtitle:I = 0x7f090056

.field public static deviceinfo:I = 0x7f090053

.field public static deviceinfolinear:I = 0x7f090051

.field public static deviceinfotitle:I = 0x7f090052

.field public static dios:I = 0x7f090087

.field public static doublequery:I = 0x7f09008b

.field public static emailusdetails:I = 0x7f090047

.field public static emailuslinear:I = 0x7f090045

.field public static emailustitle:I = 0x7f090046

.field public static end:I = 0x7f09000e

.field public static error:I = 0x7f09006d

.field public static errorbased:I = 0x7f090089

.field public static execute:I = 0x7f09007d

.field public static exiticon:I = 0x7f0900cd

.field public static exitlinear:I = 0x7f0900cc

.field public static exittext:I = 0x7f0900ce

.field public static extractlinks:I = 0x7f09009f

.field public static field:I = 0x7f0900d0

.field public static fill:I = 0x7f09000f

.field public static fill_horizontal:I = 0x7f090010

.field public static fill_vertical:I = 0x7f090011

.field public static find:I = 0x7f09005b

.field public static findclose:I = 0x7f0900b2

.field public static findcount:I = 0x7f090075

.field public static findfield:I = 0x7f0900af

.field public static findlayout:I = 0x7f0900ae

.field public static findnext:I = 0x7f0900b1

.field public static findprev:I = 0x7f0900b0

.field public static forever:I = 0x7f09001a

.field public static forward:I = 0x7f09007b

.field public static from:I = 0x7f0900b8

.field public static frozenflamedesignation:I = 0x7f090033

.field public static frozenflamelinear:I = 0x7f090031

.field public static frozenflamename:I = 0x7f090032

.field public static githubrepositorydetails:I = 0x7f09003f

.field public static githubrepositorylinear:I = 0x7f09003d

.field public static githubrepositorytitle:I = 0x7f09003e

.field public static hinttext:I = 0x7f09005f

.field public static horizontallayout:I = 0x7f0900cf

.field public static hr0:I = 0x7f090021

.field public static hr1:I = 0x7f09002c

.field public static hr2:I = 0x7f090030

.field public static hr3:I = 0x7f090034

.field public static hr4:I = 0x7f09003a

.field public static hr5:I = 0x7f090040

.field public static hr6:I = 0x7f090044

.field public static hr7:I = 0x7f09004a

.field public static hr8:I = 0x7f090050

.field public static hr9:I = 0x7f090054

.field public static icon:I = 0x7f0900d5

.field public static icon_group:I = 0x7f0900df

.field public static info:I = 0x7f0900d8

.field public static inputlayout:I = 0x7f090059

.field public static italic:I = 0x7f09001b

.field public static javascript:I = 0x7f0900a5

.field public static joinfbgroupdetails:I = 0x7f090043

.field public static joinfbgrouplinear:I = 0x7f090041

.field public static joinfbgrouptitle:I = 0x7f090042

.field public static layer1:I = 0x7f090065

.field public static layer2:I = 0x7f090067

.field public static layout:I = 0x7f09005d

.field public static left:I = 0x7f090012

.field public static lfi:I = 0x7f09008f

.field public static line1:I = 0x7f090000

.field public static line3:I = 0x7f090001

.field public static listview:I = 0x7f09005e

.field public static localvariable:I = 0x7f090088

.field public static logocontainer:I = 0x7f0900b5

.field public static masterjavadesignation:I = 0x7f09002b

.field public static masterjavalinear:I = 0x7f090029

.field public static masterjavaname:I = 0x7f09002a

.field public static mdjubayerdesignation:I = 0x7f090037

.field public static mdjubayerlinear:I = 0x7f090035

.field public static mdjubayername:I = 0x7f090036

.field public static menu:I = 0x7f090077

.field public static menuclose:I = 0x7f0900bb

.field public static mssql:I = 0x7f09008d

.field public static nethunterdesignation:I = 0x7f09002f

.field public static nethunterlinear:I = 0x7f09002d

.field public static nethuntername:I = 0x7f09002e

.field public static none:I = 0x7f090016

.field public static noredirect:I = 0x7f0900a6

.field public static normal:I = 0x7f09001c

.field public static note:I = 0x7f090058

.field public static notfoundtext:I = 0x7f090066

.field public static notification_background:I = 0x7f0900da

.field public static notification_main_column:I = 0x7f0900d6

.field public static notification_main_column_container:I = 0x7f0900d4

.field public static orderbybypass:I = 0x7f090097

.field public static pagefavicon:I = 0x7f0900ac

.field public static pagetitle:I = 0x7f0900ad

.field public static pagetitlelayout:I = 0x7f0900ab

.field public static paramsfield:I = 0x7f090078

.field public static paste:I = 0x7f090081

.field public static polygon:I = 0x7f09009a

.field public static postdata:I = 0x7f0900a3

.field public static postgresql:I = 0x7f09008e

.field public static printsystem:I = 0x7f09008a

.field public static privacypolicy:I = 0x7f09004b

.field public static progressbar:I = 0x7f09005c

.field public static rce:I = 0x7f090090

.field public static redo:I = 0x7f090074

.field public static reload:I = 0x7f09007e

.field public static replace:I = 0x7f090095

.field public static report:I = 0x7f09006f

.field public static restarticon:I = 0x7f0900be

.field public static restartlinear:I = 0x7f0900bd

.field public static restarttext:I = 0x7f0900bf

.field public static right:I = 0x7f090013

.field public static right_icon:I = 0x7f0900d9

.field public static right_side:I = 0x7f0900d7

.field public static row1:I = 0x7f09007a

.field public static row1scroll:I = 0x7f090079

.field public static row2:I = 0x7f090083

.field public static row2scroll:I = 0x7f090082

.field public static row3:I = 0x7f090094

.field public static row3scroll:I = 0x7f090093

.field public static row4:I = 0x7f0900a1

.field public static row4scroll:I = 0x7f0900a0

.field public static save:I = 0x7f0900e1

.field public static savelasturldetails:I = 0x7f0900e7

.field public static savelasturllinear:I = 0x7f0900e4

.field public static savelasturlsetting:I = 0x7f0900e6

.field public static savelasturlswitch:I = 0x7f0900e8

.field public static savelasturlverticallinear:I = 0x7f0900e5

.field public static scroll:I = 0x7f090022

.field public static scrolllinear:I = 0x7f090023

.field public static settingsicon:I = 0x7f0900c4

.field public static settingslinear:I = 0x7f0900c3

.field public static settingstext:I = 0x7f0900c5

.field public static shareicon:I = 0x7f0900ca

.field public static sharelinear:I = 0x7f0900c9

.field public static sharetext:I = 0x7f0900cb

.field public static showhide:I = 0x7f090076

.field public static sociallinkstitle:I = 0x7f09003c

.field public static specialthanksto:I = 0x7f090039

.field public static start:I = 0x7f090014

.field public static stop:I = 0x7f09007f

.field public static subtitle:I = 0x7f09006c

.field public static systeminfotitle:I = 0x7f09004c

.field public static tag_transition_group:I = 0x7f090002

.field public static tag_unhandled_key_event_manager:I = 0x7f090003

.field public static tag_unhandled_key_listeners:I = 0x7f090004

.field public static tamperdata:I = 0x7f0900a4

.field public static termsandconditions:I = 0x7f090049

.field public static text:I = 0x7f090005

.field public static text2:I = 0x7f090006

.field public static textcontainer:I = 0x7f0900b7

.field public static textsizedetails:I = 0x7f0900ec

.field public static textsizelinear:I = 0x7f0900e9

.field public static textsizeseekbar:I = 0x7f0900ed

.field public static textsizesetting:I = 0x7f0900eb

.field public static textsizeverticallinear:I = 0x7f0900ea

.field public static thanksto:I = 0x7f09003b

.field public static time:I = 0x7f0900db

.field public static title:I = 0x7f090007

.field public static titlefield:I = 0x7f0900e2

.field public static top:I = 0x7f090015

.field public static topbar:I = 0x7f09001e

.field public static toplinear:I = 0x7f090069

.field public static tutorialicon:I = 0x7f0900c1

.field public static tutoriallinear:I = 0x7f0900c0

.field public static tutorialtext:I = 0x7f0900c2

.field public static undo:I = 0x7f090073

.field public static unionselectbypass:I = 0x7f090098

.field public static unionstatements:I = 0x7f090085

.field public static uploader:I = 0x7f09009e

.field public static urlbalancer:I = 0x7f090099

.field public static urlfield:I = 0x7f09005a

.field public static use:I = 0x7f0900e0

.field public static useragent:I = 0x7f0900aa

.field public static userprivileges:I = 0x7f09009d

.field public static versionname:I = 0x7f090026

.field public static verticallinear:I = 0x7f0900bc

.field public static viewsource:I = 0x7f0900a2

.field public static viewsourcelinear:I = 0x7f0900ee

.field public static viewsourcemethod:I = 0x7f0900f0

.field public static viewsourcesetting:I = 0x7f0900ef

.field public static wafbypass:I = 0x7f090096

.field public static webtools:I = 0x7f0900a9

.field public static webview:I = 0x7f0900b4

.field public static webviewcontainer:I = 0x7f0900b3

.field public static whattodo:I = 0x7f09006e

.field public static writablepath:I = 0x7f09009b

.field public static xpathinjection:I = 0x7f09008c

.field public static xss:I = 0x7f090091


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.integer (androidx.browser.R$integer)
.class public final Landroidx/browser/R$integer;
.super Ljava/lang/Object;


# static fields
.field public static google_play_services_version:I = 0x7f050000

.field public static status_bar_notification_info_maxnum:I = 0x7f050001


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.layout (androidx.browser.R$layout)
.class public final Landroidx/browser/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static about:I = 0x7f030000

.field public static admin:I = 0x7f030001

.field public static browser_actions_context_menu_page:I = 0x7f030002

.field public static browser_actions_context_menu_row:I = 0x7f030003

.field public static customquery:I = 0x7f030004

.field public static debug:I = 0x7f030005

.field public static griditem:I = 0x7f030006

.field public static hackbar:I = 0x7f030007

.field public static listitem:I = 0x7f030008

.field public static main:I = 0x7f030009

.field public static menu:I = 0x7f03000a

.field public static note:I = 0x7f03000b

.field public static notification_action:I = 0x7f03000c

.field public static notification_action_tombstone:I = 0x7f03000d

.field public static notification_template_custom_big:I = 0x7f03000e

.field public static notification_template_icon_group:I = 0x7f03000f

.field public static notification_template_part_chronometer:I = 0x7f030010

.field public static notification_template_part_time:I = 0x7f030011

.field public static permission:I = 0x7f030012

.field public static query:I = 0x7f030013

.field public static settings:I = 0x7f030014

.field public static webtool:I = 0x7f030015


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.string (androidx.browser.R$string)
.class public final Landroidx/browser/R$string;
.super Ljava/lang/Object;


# static fields
.field public static app_name:I = 0x7f060009

.field public static common_google_play_services_unknown_issue:I = 0x7f060000

.field public static s1:I = 0x7f060002

.field public static s2:I = 0x7f060003

.field public static s3:I = 0x7f060004

.field public static s4:I = 0x7f060005

.field public static s5:I = 0x7f060006

.field public static s6:I = 0x7f060007

.field public static s7:I = 0x7f060008

.field public static status_bar_notification_info_overflow:I = 0x7f060001


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.style (androidx.browser.R$style)
.class public final Landroidx/browser/R$style;
.super Ljava/lang/Object;


# static fields
.field public static AppTheme:I = 0x7f040009

.field public static FullScreen:I = 0x7f04000a

.field public static NoActionBar:I = 0x7f04000b

.field public static NoStatusBar:I = 0x7f04000c

.field public static TextAppearance_Compat_Notification:I = 0x7f040002

.field public static TextAppearance_Compat_Notification_Info:I = 0x7f040003

.field public static TextAppearance_Compat_Notification_Line2:I = 0x7f040008

.field public static TextAppearance_Compat_Notification_Time:I = 0x7f040004

.field public static TextAppearance_Compat_Notification_Title:I = 0x7f040005

.field public static Theme_IAPTheme:I = 0x7f040000

.field public static Widget_Compat_NotificationActionContainer:I = 0x7f040006

.field public static Widget_Compat_NotificationActionText:I = 0x7f040007

.field public static Widget_Support_CoordinatorLayout:I = 0x7f040001


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class androidx.browser.R.styleable (androidx.browser.R$styleable)
.class public final Landroidx/browser/R$styleable;
.super Ljava/lang/Object;


# static fields
.field public static final AdsAttrs:[I

.field public static AdsAttrs_adSize:I

.field public static AdsAttrs_adSizes:I

.field public static AdsAttrs_adUnitId:I

.field public static final ColorStateListItem:[I

.field public static ColorStateListItem_alpha:I

.field public static ColorStateListItem_android_alpha:I

.field public static ColorStateListItem_android_color:I

.field public static final CoordinatorLayout:[I

.field public static final CoordinatorLayout_Layout:[I

.field public static CoordinatorLayout_Layout_android_layout_gravity:I

.field public static CoordinatorLayout_Layout_layout_anchor:I

.field public static CoordinatorLayout_Layout_layout_anchorGravity:I

.field public static CoordinatorLayout_Layout_layout_behavior:I

.field public static CoordinatorLayout_Layout_layout_dodgeInsetEdges:I

.field public static CoordinatorLayout_Layout_layout_insetEdge:I

.field public static CoordinatorLayout_Layout_layout_keyline:I

.field public static CoordinatorLayout_keylines:I

.field public static CoordinatorLayout_statusBarBackground:I

.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static FontFamilyFont_android_font:I

.field public static FontFamilyFont_android_fontStyle:I

.field public static FontFamilyFont_android_fontVariationSettings:I

.field public static FontFamilyFont_android_fontWeight:I

.field public static FontFamilyFont_android_ttcIndex:I

.field public static FontFamilyFont_font:I

.field public static FontFamilyFont_fontStyle:I

.field public static FontFamilyFont_fontVariationSettings:I

.field public static FontFamilyFont_fontWeight:I

.field public static FontFamilyFont_ttcIndex:I

.field public static FontFamily_fontProviderAuthority:I

.field public static FontFamily_fontProviderCerts:I

.field public static FontFamily_fontProviderFetchStrategy:I

.field public static FontFamily_fontProviderFetchTimeout:I

.field public static FontFamily_fontProviderPackage:I

.field public static FontFamily_fontProviderQuery:I

.field public static final GradientColor:[I

.field public static final GradientColorItem:[I

.field public static GradientColorItem_android_color:I

.field public static GradientColorItem_android_offset:I

.field public static GradientColor_android_centerColor:I

.field public static GradientColor_android_centerX:I

.field public static GradientColor_android_centerY:I

.field public static GradientColor_android_endColor:I

.field public static GradientColor_android_endX:I

.field public static GradientColor_android_endY:I

.field public static GradientColor_android_gradientRadius:I

.field public static GradientColor_android_startColor:I

.field public static GradientColor_android_startX:I

.field public static GradientColor_android_startY:I

.field public static GradientColor_android_tileMode:I

.field public static GradientColor_android_type:I


# direct methods
.method static constructor <clinit>()V
    .registers 12

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_a6

    sput-object v1, Landroidx/browser/R$styleable;->AdsAttrs:[I

    const/4 v1, 0x0

    sput v1, Landroidx/browser/R$styleable;->AdsAttrs_adSize:I

    const/4 v2, 0x1

    sput v2, Landroidx/browser/R$styleable;->AdsAttrs_adSizes:I

    const/4 v3, 0x2

    sput v3, Landroidx/browser/R$styleable;->AdsAttrs_adUnitId:I

    new-array v4, v0, [I

    fill-array-data v4, :array_b0

    sput-object v4, Landroidx/browser/R$styleable;->ColorStateListItem:[I

    sput v3, Landroidx/browser/R$styleable;->ColorStateListItem_alpha:I

    sput v2, Landroidx/browser/R$styleable;->ColorStateListItem_android_alpha:I

    sput v1, Landroidx/browser/R$styleable;->ColorStateListItem_android_color:I

    new-array v4, v3, [I

    fill-array-data v4, :array_ba

    sput-object v4, Landroidx/browser/R$styleable;->CoordinatorLayout:[I

    sput v1, Landroidx/browser/R$styleable;->CoordinatorLayout_keylines:I

    sput v2, Landroidx/browser/R$styleable;->CoordinatorLayout_statusBarBackground:I

    const/4 v4, 0x7

    new-array v5, v4, [I

    fill-array-data v5, :array_c2

    sput-object v5, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout:[I

    sput v1, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_android_layout_gravity:I

    sput v3, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_anchor:I

    const/4 v5, 0x4

    sput v5, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_anchorGravity:I

    sput v2, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_behavior:I

    const/4 v6, 0x6

    sput v6, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_dodgeInsetEdges:I

    const/4 v7, 0x5

    sput v7, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_insetEdge:I

    sput v0, Landroidx/browser/R$styleable;->CoordinatorLayout_Layout_layout_keyline:I

    new-array v8, v6, [I

    fill-array-data v8, :array_d4

    sput-object v8, Landroidx/browser/R$styleable;->FontFamily:[I

    sput v1, Landroidx/browser/R$styleable;->FontFamily_fontProviderAuthority:I

    sput v0, Landroidx/browser/R$styleable;->FontFamily_fontProviderCerts:I

    sput v5, Landroidx/browser/R$styleable;->FontFamily_fontProviderFetchStrategy:I

    sput v7, Landroidx/browser/R$styleable;->FontFamily_fontProviderFetchTimeout:I

    sput v2, Landroidx/browser/R$styleable;->FontFamily_fontProviderPackage:I

    sput v3, Landroidx/browser/R$styleable;->FontFamily_fontProviderQuery:I

    const/16 v8, 0xa

    new-array v9, v8, [I

    fill-array-data v9, :array_e4

    sput-object v9, Landroidx/browser/R$styleable;->FontFamilyFont:[I

    sput v1, Landroidx/browser/R$styleable;->FontFamilyFont_android_font:I

    sput v3, Landroidx/browser/R$styleable;->FontFamilyFont_android_fontStyle:I

    sput v5, Landroidx/browser/R$styleable;->FontFamilyFont_android_fontVariationSettings:I

    sput v2, Landroidx/browser/R$styleable;->FontFamilyFont_android_fontWeight:I

    sput v0, Landroidx/browser/R$styleable;->FontFamilyFont_android_ttcIndex:I

    sput v6, Landroidx/browser/R$styleable;->FontFamilyFont_font:I

    sput v7, Landroidx/browser/R$styleable;->FontFamilyFont_fontStyle:I

    const/16 v9, 0x8

    sput v9, Landroidx/browser/R$styleable;->FontFamilyFont_fontVariationSettings:I

    sput v4, Landroidx/browser/R$styleable;->FontFamilyFont_fontWeight:I

    const/16 v10, 0x9

    sput v10, Landroidx/browser/R$styleable;->FontFamilyFont_ttcIndex:I

    const/16 v11, 0xc

    new-array v11, v11, [I

    fill-array-data v11, :array_fc

    sput-object v11, Landroidx/browser/R$styleable;->GradientColor:[I

    sput v4, Landroidx/browser/R$styleable;->GradientColor_android_centerColor:I

    sput v0, Landroidx/browser/R$styleable;->GradientColor_android_centerX:I

    sput v5, Landroidx/browser/R$styleable;->GradientColor_android_centerY:I

    sput v2, Landroidx/browser/R$styleable;->GradientColor_android_endColor:I

    sput v8, Landroidx/browser/R$styleable;->GradientColor_android_endX:I

    const/16 v0, 0xb

    sput v0, Landroidx/browser/R$styleable;->GradientColor_android_endY:I

    sput v7, Landroidx/browser/R$styleable;->GradientColor_android_gradientRadius:I

    sput v1, Landroidx/browser/R$styleable;->GradientColor_android_startColor:I

    sput v9, Landroidx/browser/R$styleable;->GradientColor_android_startX:I

    sput v10, Landroidx/browser/R$styleable;->GradientColor_android_startY:I

    sput v6, Landroidx/browser/R$styleable;->GradientColor_android_tileMode:I

    sput v3, Landroidx/browser/R$styleable;->GradientColor_android_type:I

    new-array v0, v3, [I

    fill-array-data v0, :array_118

    sput-object v0, Landroidx/browser/R$styleable;->GradientColorItem:[I

    sput v1, Landroidx/browser/R$styleable;->GradientColorItem_android_color:I

    sput v2, Landroidx/browser/R$styleable;->GradientColorItem_android_offset:I

    return-void

    nop

    :array_a6
    .array-data 4
        0x7f010000
        0x7f010001
        0x7f010002
    .end array-data

    :array_b0
    .array-data 4
        0x10101a5
        0x101031f
        0x7f01000c
    .end array-data

    :array_ba
    .array-data 4
        0x7f010004
        0x7f010005
    .end array-data

    :array_c2
    .array-data 4
        0x10100b3
        0x7f010006
        0x7f010007
        0x7f010008
        0x7f010009
        0x7f01000a
        0x7f01000b
    .end array-data

    :array_d4
    .array-data 4
        0x7f01000d
        0x7f01000e
        0x7f01000f
        0x7f010010
        0x7f010011
        0x7f010012
    .end array-data

    :array_e4
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f010013
        0x7f010014
        0x7f010015
        0x7f010016
        0x7f010017
    .end array-data

    :array_fc
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data

    :array_118
    .array-data 4
        0x10101a5
        0x1010514
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
